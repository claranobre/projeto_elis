#ifndef _CLI_H_
#define _CLI_H_


class CLI
{
    public:
        CLI();
        ~CLI();

};
#endif
