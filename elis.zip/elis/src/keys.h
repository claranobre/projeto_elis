#ifndef _KEYS_H_
#define _KEYS_H_

namespace Elis
{
    enum Keys
    {
        QUIT = 'q',
        ENTER = '\n',
        ESCAPE = 27,
        DELETE = 127,
        BACKSPACE = '\b',
    };
}

#endif
