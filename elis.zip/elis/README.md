ELIS
====

Editor de Textos orientado a Linhas, ou simplesmente ELIS, é um programa de linha de comando desenvolvido como projeto na disciplina de *Estruturas de dados básicas I*.

## Como compilar

Execute o comando `make` para compilar o código-fonte do projeto em um arquivo executável chamado `elis`.

  $ make

## Como usar

Após compilado um arquivo executável `elis` estará¡ disponável no diretório rais do projeto, execute-o conforme mostrado abaixo para acessar a interface do programa.

  $ ./elis

## LimitaÃ§Ãµes atuais

Atualmente o `elis` é capaz apenas de escrever em arquivo o conteúdo digitado pelo usuário.
